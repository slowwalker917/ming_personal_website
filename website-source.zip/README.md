# Ming Ge 个人网站

这是独立于旧 blogdown/Hugo 项目的新版网站。内容来自 2026 年 10 月 CV、新 WIC 求职论文，以及你确认的信息。网站为英文，维护说明为中文。当前是本地预览版本，尚未替换线上网站。

## 最常见的更新

| 要更新什么 | 修改位置 | 做法 |
| --- | --- | --- |
| 简历 | `files/cv.pdf` | 用新 PDF 覆盖，保留这个文件名 |
| Job Market Paper | `files/job-market-paper.pdf` | 用新论文覆盖，保留这个文件名 |
| 照片 | `assets/photo.jpg` | 用新 JPG 覆盖，保留这个文件名 |
| 首页简介、邮箱、所在地、学术链接 | `content/site.json` → `profile` | 改对应文字 |
| 论文标题、作者、投稿状态、摘要 | `content/site.json` → `research` | 改对应条目，按数组顺序显示 |
| 教学信息 | `content/site.json` → `teaching` | 增删或修改课程条目 |
| 页脚更新月份 | `content/site.json` → `site.updated` | 例如 `November 2026` |

**不用改 HTML 或 CSS，也不需要 R、Hugo 或额外 Node 包。** 本地生成需要 Node.js 20 或以上；本机的启动脚本也能使用 Codex 已安装的 Node。

### 看预览

双击 `PREVIEW.cmd`，保持出现的终端窗口开启，然后在浏览器打开 <http://127.0.0.1:4173/>。修改内容或替换文件后刷新页面，预览会自动重新生成。关闭终端会停止预览。

### 准备发布文件

双击 `BUILD.cmd`。成功后，`dist/` 是完整静态网站。不要手动修改 `dist/` 里的文件，它们会在下次生成时被覆盖。

也可以在此文件夹打开终端运行：

```text
npm run build
npm run check
npm run preview
```

没有需要安装的依赖。以后接到 GitHub/Netlify 时，Netlify 使用 `netlify.toml` 中的命令自动生成。将 `dist/` 上传到原 Netlify 项目也可以。首次替换线上网站应确认该项目实际关联的仓库和部署方式；本地生成本身不会上传或发布。

## 添加论文

1. 将准备公开的 PDF 放入 `files/`，例如 `files/my-paper.pdf`。文件名用英文字母、数字和连字符。
2. 在 `content/site.json` 的相应列表中复制一条论文记录，再修改文字。每篇论文的 `id` 必须不同，例如 `my-new-paper`。
3. 有 PDF 时，在这篇论文的 `links` 中填入：

```json
"links": [
  { "label": "Read paper", "url": "files/my-paper.pdf", "type": "pdf" }
]
```

有 SSRN、期刊或 slides 链接，也可以在 `links` 里增加记录。链接可以是完整 `https://` 地址。只有准备公开的文件才放进 `files/`，这个目录会整体进入发布文件。

摘要用 `"abstract": "摘要全文"` 添加，会自动变成可展开的 Abstract。短介绍用 `"summary": "两三句话"`；投稿状态用 `"status": "状态"`。不需要的可选项可以删除。没有下载链接时使用 `"links": []`，页面不会出现空按钮。

JSON 注意保留英文双引号和条目间逗号。引号里的内容可以是中文或英文。文本中的英文双引号要写成 `\"`。若格式或文件路径错误，生成脚本会指出问题，不会修改你的原始内容。

## 文件说明

- `content/site.json`：唯一的网页文字来源。
- `assets/`：照片、图标和样式。
- `files/`：要公开的 CV、论文和教学 PDF。
- `scripts/`：生成、检查和本地预览程序，日常更新不用改。
- `dist/`：生成结果，可整体部署。
- 根目录最初上传的 CV 和 `Job Market Paper.pdf`：保留的原始副本。日后更新网站请替换 `files/` 中的固定文件，避免改错副本。

## 内容依据与待补充内容

- 学位、论文标题、作者顺序、教学记录：`Ming_Ge_CV_10_05_2026.pdf`。
- UF 博士后已结束：按本人确认，以过去时表述 2023–2026 年的经历。
- WIC 摘要及 PDF：本人提供的 `Job Market Paper.pdf`。研究页使用论文正文里的最新摘要；投稿状态沿用 CV 的 **Reject/Resubmit**，没有改写成 Revise & Resubmit。
- Food Policy 论文：CV 及 DOI `https://doi.org/10.1016/j.foodpol.2026.103172`。不额外推断尚未提供的投稿或发表状态。
- 照片：上一级目录中的 `you.jpg`，仅复制，没有修图。
- 2022 年统计课 syllabus：从旧网站恢复。课程日期仍保留 2022 年。
- 其他 working papers 目前只列新 CV 中的标题及作者；未使用旧摘要或把旧稿冒充最新版。
- `files/reputation-search-paper.pdf` 仅用于保留旧 `/uploads/JMP.pdf` 链接的语义，新首页 JMP 始终链接到 WIC 论文。旧稿不显示在新版论文下载按钮里。
- 当前没有擅自增加求职季节、现任单位、参考人联系方式、电话、家庭地址或新增成果。

## 可维护性

生成器把内容编译成普通 HTML。浏览器无需 JavaScript 即可读到完整内容，Abstract 使用原生折叠组件。字体使用系统字体，不依赖外部字体服务；也没有统计追踪、登录系统或数据库。更换托管平台时可继续使用同一份 `dist/`。

生成器记录自己复制到 `dist/` 的文件。删除或改名源文件后，下次生成会清理对应的旧输出；不会删除原始上传文件或不属于生成器的文件。如果网页内容仍链接到已删除的文件，生成会报错，先修改 `content/site.json` 的链接即可。
