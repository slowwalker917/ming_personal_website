const carousel = document.querySelector('[data-carousel]');

if (carousel) {
  const slides = [...carousel.querySelectorAll('[data-carousel-slide]')];
  const dots = [...carousel.querySelectorAll('[data-carousel-dot]')];
  const caption = carousel.querySelector('[data-carousel-caption]');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let current = 0;
  let timer;

  const show = index => {
    current = (index + slides.length) % slides.length;
    slides.forEach((slide, slideIndex) => {
      const active = slideIndex === current;
      slide.classList.toggle('is-active', active);
      slide.setAttribute('aria-hidden', String(!active));
    });
    dots.forEach((dot, dotIndex) => {
      const active = dotIndex === current;
      dot.classList.toggle('is-active', active);
      dot.setAttribute('aria-pressed', String(active));
    });
    if (caption) caption.textContent = slides[current].dataset.caption || '';
  };

  const stop = () => window.clearInterval(timer);
  const start = () => {
    stop();
    if (!reduceMotion.matches && !document.hidden) {
      timer = window.setInterval(() => show(current + 1), 5500);
    }
  };

  dots.forEach((dot, index) => dot.addEventListener('click', () => {
    show(index);
    start();
  }));
  carousel.addEventListener('pointerenter', stop);
  carousel.addEventListener('pointerleave', start);
  carousel.addEventListener('focusin', stop);
  carousel.addEventListener('focusout', start);
  document.addEventListener('visibilitychange', start);
  reduceMotion.addEventListener?.('change', start);
  start();
}

const zoomableFigures = [...document.querySelectorAll('[data-lightbox]')];

if (zoomableFigures.length) {
  const lightbox = document.createElement('div');
  lightbox.className = 'figure-lightbox';
  lightbox.hidden = true;
  lightbox.setAttribute('role', 'dialog');
  lightbox.setAttribute('aria-modal', 'true');
  lightbox.setAttribute('aria-label', 'Expanded research figure');
  lightbox.innerHTML = '<div class="figure-lightbox-inner"><button class="figure-lightbox-close" type="button" aria-label="Close expanded figure">×</button><img class="figure-lightbox-image" alt=""><p class="figure-lightbox-caption"></p></div>';
  document.body.append(lightbox);
  const image = lightbox.querySelector('.figure-lightbox-image');
  const caption = lightbox.querySelector('.figure-lightbox-caption');
  const closeButton = lightbox.querySelector('.figure-lightbox-close');
  let trigger;

  const close = () => {
    lightbox.hidden = true;
    document.body.classList.remove('lightbox-open');
    trigger?.focus();
  };

  const open = figure => {
    trigger = figure;
    image.src = figure.currentSrc || figure.src;
    image.alt = figure.alt;
    caption.textContent = figure.dataset.caption || figure.alt;
    lightbox.hidden = false;
    document.body.classList.add('lightbox-open');
    closeButton.focus();
  };

  zoomableFigures.forEach(figure => {
    figure.addEventListener('click', () => open(figure));
    figure.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        open(figure);
      }
    });
  });
  lightbox.addEventListener('click', close);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !lightbox.hidden) close();
  });
}
