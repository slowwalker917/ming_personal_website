import { readFile, writeFile, mkdir, cp, stat, readdir, unlink } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'dist');
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const ext = url => /^https?:\/\//i.test(url);
const arrow = '<span class="arrow" aria-hidden="true">↗</span>';

async function listFiles(directory, prefix = '') {
  const result = [];
  for (const entry of await readdir(directory, {withFileTypes:true})) {
    if (entry.isSymbolicLink()) throw new Error(`Symbolic links are not supported in published files: ${entry.name}`);
    const name = `${prefix}${entry.name}`;
    if (entry.isDirectory()) result.push(...await listFiles(path.join(directory,entry.name), `${name}/`));
    else if (entry.isFile()) result.push(name);
  }
  return result;
}

function validate(data) {
  const need = (value, label) => { if (typeof value !== 'string' || !value.trim()) throw new Error(`Missing text: ${label}`); };
  need(data.site?.name, 'site.name');
  need(data.site?.url, 'site.url');
  if (!/^https:\/\//.test(data.site.url)) throw new Error('site.url must start with https://');
  for (const key of ['email', 'photo', 'cv', 'intro', 'qualification']) need(data.profile?.[key], `profile.${key}`);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.profile.email)) throw new Error('profile.email is not a valid email address.');
  for (const key of ['bio', 'fields', 'links']) if (!Array.isArray(data.profile[key])) throw new Error(`profile.${key} must be a list.`);
  for (const key of ['publications','workingPapers','extensionArticles','workInProgress']) if (!Array.isArray(data.research?.[key])) throw new Error(`research.${key} must be a list.`);
  if (!data.research?.jobMarketPaper?.links?.some(link => link.type === 'pdf')) throw new Error('The job market paper needs a PDF link.');
  if (!Array.isArray(data.teaching?.groups)) throw new Error('teaching.groups must be a list.');
  const ids = new Set();
  for (const paper of [data.research.jobMarketPaper, ...data.research.publications, ...data.research.workingPapers, ...data.research.extensionArticles, ...data.research.workInProgress]) {
    need(paper.title, 'paper.title');
    if (!/^[a-z0-9-]+$/.test(paper.id) || ids.has(paper.id)) throw new Error(`Paper id must be unique and use lowercase letters, digits or hyphens: ${paper.id}`);
    ids.add(paper.id);
    if (paper.authors && !Array.isArray(paper.authors)) throw new Error(`authors must be a list for ${paper.id}`);
  }
  for (const group of data.teaching.groups) {
    need(group.title, 'teaching group title');
    if (!Array.isArray(group.courses)) throw new Error(`courses must be a list for ${group.title}`);
    for (const course of group.courses) for (const key of ['title','institution','term']) need(course[key], `course.${key}`);
  }
}

async function validateFiles(data) {
  const files = new Set([data.profile.photo]);
  const inspect = item => {
    if (!item || typeof item !== 'object') return;
    if (typeof item.url === 'string') {
      const value = item.url;
      if (!ext(value)) {
        if (!/^(assets|files)\/[a-zA-Z0-9._/-]+$/.test(value) || value.split('/').includes('..')) throw new Error(`Unsupported or unsafe link: ${value}`);
        files.add(value);
      }
    }
    for (const value of Object.values(item)) if (typeof value === 'object') inspect(value);
  };
  inspect({url:data.profile.cv});
  inspect(data.profile.links); inspect(data.research); inspect(data.teaching);
  for (const file of files) {
    const full = path.resolve(root, file);
    if (!full.startsWith(root + path.sep)) throw new Error(`File outside project: ${file}`);
    if (!(await stat(full).catch(() => null))?.isFile()) throw new Error(`Missing file: ${file}. Copy it into the project or update content/site.json.`);
  }
}

export async function build({quiet = false} = {}) {
  let data;
  try { data = JSON.parse(await readFile(path.join(root, 'content/site.json'), 'utf8')); }
  catch (error) { throw new Error(`Cannot read content/site.json. Check quotation marks and commas. ${error.message}`); }
  validate(data);
  await validateFiles(data);
  const { site, profile, research, teaching } = data;
  const href = (url, depth = 0) => ext(url) || url.startsWith('mailto:') || url.startsWith('#') ? escape(url) : `${'../'.repeat(depth)}${escape(url)}`;
  const link = (item, depth = 0, className = '') => `<a href="${href(item.url, depth)}"${className ? ` class="${className}"` : ''}${ext(item.url) ? ' target="_blank" rel="noopener noreferrer"' : ''}>${escape(item.label)}${item.type === 'pdf' ? '<span class="file-tag">PDF</span>' : arrow}</a>`;
  const authors = paper => paper.authors?.length ? `<p class="paper-authors">${paper.authors.map(name => `<span${name === site.name ? ' class="self"' : ''}>${escape(name)}</span>`).join(', ')}</p>` : (paper.collaborators ? `<p class="paper-authors">${escape(paper.collaborators)}</p>` : '');
  const citation = paper => paper.venue ? `<p class="publication-venue"><em>${escape(paper.venue)}</em> · ${escape(paper.citation)}</p>` : '';
  const paperLinks = (paper, depth = 0) => paper.links?.length ? `<div class="paper-links">${paper.links.map(item => link(item, depth)).join('')}</div>` : '';
  const abstract = paper => paper.abstract ? `<details class="abstract"><summary>Abstract</summary><p>${escape(paper.abstract)}</p></details>` : '';
  const paper = (item, featured = false) => `<article class="paper${featured ? ' featured' : ''}" id="${escape(item.id)}"><h3>${escape(item.title)}</h3>${authors(item)}${citation(item)}${item.status ? `<p class="paper-status">${escape(item.status)}</p>` : ''}${item.summary ? `<p class="paper-summary">${escape(item.summary)}</p>` : ''}${item.note ? `<p class="paper-note">${escape(item.note)}</p>` : ''}${paperLinks(item, 1)}${abstract(item)}</article>`;
  const jmp = research.jobMarketPaper;
  const jmpPdf = jmp.links.find(item => item.type === 'pdf');

  const shell = (page, content, {title, description, depth = 0} = {}) => {
    const pagePath = page === 'home' ? '' : `${page}/`;
    const canonical = `${site.url.replace(/\/$/, '')}/${pagePath}`;
    const nav = [
      ['Home', depth ? '../' : './', 'home'],
      ['Research', depth ? '../research/' : 'research/', 'research'],
      ['Teaching', depth ? '../teaching/' : 'teaching/', 'teaching']
    ].map(([label,url,key]) => `<a href="${url}"${page === key ? ' aria-current="page"' : ''}>${label}</a>`).join('');
    return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escape(title ?? `${site.name} | ${profile.qualification}`)}</title>
<meta name="description" content="${escape(description ?? site.description)}">
<meta name="theme-color" content="#285b54">
<link rel="canonical" href="${escape(canonical)}">
<meta property="og:type" content="website">
<meta property="og:title" content="${escape(title ?? `${site.name} | ${profile.qualification}`)}">
<meta property="og:description" content="${escape(description ?? site.description)}">
<meta property="og:url" content="${escape(canonical)}">
<meta property="og:image" content="${escape(site.url)}/${escape(profile.photo)}">
<link rel="icon" type="image/svg+xml" href="${href('assets/favicon.svg', depth)}">
<link rel="stylesheet" href="${href('assets/site.css', depth)}">
</head>
<body class="${page}-page">
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header"><div class="container header-inner"><a class="brand" href="${depth ? '../' : './'}" aria-label="${escape(site.name)} home">${escape(site.name)}<span aria-hidden="true" style="color:var(--accent)">.</span></a><nav class="main-nav" aria-label="Main navigation">${nav}<a class="nav-cv" href="${href(profile.cv, depth)}" aria-label="Curriculum vitae, PDF">CV ${arrow}</a></nav></div></header>
<main id="main" class="container">${content}</main>
<footer class="site-footer"><div class="container footer-inner"><span>© ${escape(site.year)} ${escape(site.name)}</span><div class="footer-meta"><a href="mailto:${escape(profile.email)}">${escape(profile.email)}</a><span>Updated ${escape(site.updated)}</span></div></div></footer>
</body>
</html>\n`;
  };

  const home = `<section class="home-hero" id="about" aria-labelledby="profile-name">
<aside class="profile-column" id="contact" aria-label="Profile and contact"><img class="portrait" src="${href(profile.photo)}" alt="Portrait of ${escape(site.name)}" width="285" height="308" fetchpriority="high"><div class="profile-contact"><a href="mailto:${escape(profile.email)}">${escape(profile.email)}</a>${profile.secondaryEmail ? `<a href="mailto:${escape(profile.secondaryEmail)}">${escape(profile.secondaryEmail)}</a>` : ''}<p class="location">${escape(profile.location)}</p><div class="profile-links">${profile.links.map(item => link(item)).join('')}</div></div></aside>
<div class="intro-column"><h1 id="profile-name">${escape(site.name)}</h1><p class="qualification">${escape(profile.qualification)}</p><p class="intro"><span class="intro-greeting">${escape(profile.intro)}</span><span class="intro-market">I’m ${escape(site.name)}.${profile.marketStatus ? ` <strong>${escape(profile.marketStatus)}</strong>` : ''}</span></p>${profile.bio.map(text => `<p class="bio">${escape(text)}</p>`).join('')}<div class="actions">${link({label:'Curriculum Vitae',url:profile.cv},0,'button primary')}${link({label:'Job Market Paper',url:jmpPdf.url},0,'button')}</div></div>
</section>
<section class="fields-strip" aria-label="Research fields"><p class="eyebrow">Research fields</p><ul class="field-list">${profile.fields.map(field => `<li>${escape(field)}</li>`).join('')}</ul></section>
<section class="home-section" aria-labelledby="featured-label"><div class="section-heading"><p class="eyebrow" id="featured-label">Job Market Paper</p></div><div class="featured-grid"><div><h2>${escape(jmp.title)}</h2>${authors(jmp)}<p class="paper-status">${escape(jmp.status)}</p></div><div class="featured-aside"><p>${escape(jmp.summary)}</p>${paperLinks(jmp)}</div></div></section>
${research.publications.length ? `<section class="home-section publication-home" aria-labelledby="publication-label"><div class="section-heading"><p class="eyebrow" id="publication-label">Publication</p></div><h2>${escape(research.publications[0].title)}</h2>${authors(research.publications[0])}${citation(research.publications[0])}${paperLinks(research.publications[0])}</section>` : ''}
${profile.references?.length ? `<section class="home-section references-home" aria-labelledby="references-label"><div class="section-heading"><p class="eyebrow" id="references-label">References</p></div><div class="references-grid">${profile.references.map(reference => `<article class="reference"><h2><a href="${escape(reference.url)}" target="_blank" rel="noopener noreferrer">${escape(reference.name)}</a> <span class="reference-relationship">(${escape(reference.relationship)})</span></h2><p>${escape(reference.position)}</p><p>${escape(reference.department)}</p><p>${escape(reference.institution)}</p></article>`).join('')}</div></section>` : ''}`;

  const sections = [
    ['job-market-paper','Job Market Paper',[jmp],true],
    ['publications','Publications',research.publications,false],
    ['working-papers','Working Papers',research.workingPapers,false],
    ['extension-and-outreach','Extension & Outreach Articles',research.extensionArticles,false],
    ['work-in-progress','Work in Progress',research.workInProgress,false]
  ].filter(([, ,items]) => items.length);
  const researchBody = `<header class="page-heading"><p class="eyebrow">Research agenda</p><h1>Research</h1><p>${escape(research.intro)}</p></header><div class="research-layout"><nav class="section-nav" aria-label="Research sections"><div class="section-nav-inner">${sections.map(([id,title]) => `<a href="#${id}">${title}</a>`).join('')}</div></nav><div>${sections.map(([id,title,items,featured]) => `<section class="research-section" id="${id}" aria-labelledby="heading-${id}"><h2 id="heading-${id}">${title}</h2>${items.map(item => paper(item,featured)).join('')}</section>`).join('')}</div></div>`;

  const evaluatedGroup = teaching.groups.find(group => group.note);
  const instructorNote = evaluatedGroup?.note;
  const evaluatedCourse = evaluatedGroup?.courses[0];
  const teachingBody = `<header class="page-heading"><p class="eyebrow">In the classroom</p><h1>Teaching</h1><p>${escape(teaching.intro)}</p></header><div class="teaching-layout"><aside class="teaching-aside" aria-label="Teaching evaluation">${instructorNote ? `<p class="label">Student evaluation</p><p class="evaluation">${escape(instructorNote.replace(/^Teaching evaluation:\s*/,''))}</p>${evaluatedCourse ? `<p class="evaluation-note">${escape(evaluatedCourse.title)}<br>${escape(evaluatedCourse.institution)} · ${escape(evaluatedCourse.term)}</p>` : ''}` : `<p class="label">Teaching experience</p>`}</aside><div>${teaching.groups.map(group => `<section class="teaching-group"><h2>${escape(group.title)}</h2>${group.courses.map(course => `<article class="course"><div class="course-top"><h3>${escape(course.title)}${course.code ? ` <span class="course-code">${escape(course.code)}</span>` : ''}</h3><time>${escape(course.term)}</time></div><p>${escape(course.institution)}</p>${course.description ? `<p class="description">${escape(course.description)}</p>` : ''}${course.link ? `<div class="paper-links">${link(course.link,1)}</div>` : ''}</article>`).join('')}</section>`).join('')}</div></div>`;

  // Validate all source data before touching the output. Original uploads are never changed.
  await mkdir(output,{recursive:true});
  const manifestPath=path.join(output,'.generated-files.json');
  const previousFiles=JSON.parse(await readFile(manifestPath,'utf8').catch(()=>'[]'));
  const generatedFiles=[];
  for(const directory of ['assets','files']) generatedFiles.push(...(await listFiles(path.join(root,directory))).map(file=>`${directory}/${file}`));
  for (const directory of ['assets','files']) await cp(path.join(root,directory),path.join(output,directory),{recursive:true});
  // Remove only obsolete output files previously recorded by this generator.
  // Never delete sources, unknown files, directories, or anything outside dist/.
  for(const file of previousFiles.filter(file=>!generatedFiles.includes(file))){
    if(!/^(assets|files)\//.test(file) || file.split('/').includes('..')) throw new Error('Invalid generated file manifest.');
    const target=path.resolve(output,file);
    if(!target.startsWith(output+path.sep)) throw new Error('Generated file is outside dist/.');
    await unlink(target).catch(error=>{if(error.code!=='ENOENT')throw error;});
  }
  await writeFile(manifestPath,JSON.stringify(generatedFiles,null,2));
  await mkdir(path.join(output,'research'),{recursive:true});
  await mkdir(path.join(output,'teaching'),{recursive:true});
  await writeFile(path.join(output,'index.html'),shell('home',home));
  await writeFile(path.join(output,'research/index.html'),shell('research',researchBody,{title:`Research | ${site.name}`,description:research.intro,depth:1}));
  await writeFile(path.join(output,'teaching/index.html'),shell('teaching',teachingBody,{title:`Teaching | ${site.name}`,description:teaching.intro,depth:1}));
  const missing = shell('404','<section class="not-found"><p class="eyebrow">404</p><h1>Page not found.</h1><p>This page may have moved. Please visit the homepage or browse the research.</p><a class="button" href="/">Back to home</a></section>',{title:`Page not found | ${site.name}`}).replaceAll('href="assets/','href="/assets/').replaceAll('href="./"','href="/"').replaceAll('href="research/"','href="/research/"').replaceAll('href="teaching/"','href="/teaching/"').replaceAll('href="files/','href="/files/');
  await writeFile(path.join(output,'404.html'),missing);
  await writeFile(path.join(output,'robots.txt'),`User-agent: *\nAllow: /\nSitemap: ${site.url}/sitemap.xml\n`);
  await writeFile(path.join(output,'sitemap.xml'),`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${['/','/research/','/teaching/'].map(route=>`<url><loc>${escape(site.url+route)}</loc></url>`).join('')}</urlset>\n`);
  // Netlify Drop also reads this file when deploying dist/ directly.
  await writeFile(path.join(output,'_redirects'),'/uploads/resume.pdf /files/cv.pdf 301\n/uploads/JMP.pdf /files/reputation-search-paper.pdf 301\n/courses/* /teaching/ 301\n/publication/* /research/ 301\n');
  await writeFile(path.join(output,'_headers'),'/files/*\n  Cache-Control: public, max-age=0, must-revalidate\n/assets/*\n  Cache-Control: public, max-age=0, must-revalidate\n/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n');
  if (!quiet) console.log('Built 3 pages in dist/. Content: content/site.json. PDFs: files/. Photo: assets/photo.jpg.');
  return {output,data};
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  build().catch(error => {console.error(`Build failed: ${error.message}`);process.exitCode=1;});
}
