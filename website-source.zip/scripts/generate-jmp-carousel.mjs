import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = name => path.join(root, 'assets', name);
const accent = '#285b54';
const ink = '#222c2a';
const muted = '#66716d';

const esc = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const svgShell = (title, body, note = '') => `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="900" viewBox="0 0 1200 900" role="img" aria-labelledby="title desc">
  <title id="title">${esc(title)}</title>
  <desc id="desc">${esc(note || title)}</desc>
  <rect width="1200" height="900" fill="#fff"/>
  <text x="600" y="72" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-size="36" fill="${ink}">${esc(title)}</text>
  <line x1="78" y1="104" x2="1122" y2="104" stroke="#dfe5e2" stroke-width="2"/>
  ${body}
  ${note ? `<text x="600" y="850" text-anchor="middle" font-family="Arial, sans-serif" font-size="15" fill="${muted}">${esc(note)}</text>` : ''}
</svg>`;

const polar = (cx, cy, r, angle) => {
  const rad = (angle - 90) * Math.PI / 180;
  return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)];
};

const arc = (cx, cy, r, start, end, attrs = '') => {
  const [x1,y1] = polar(cx,cy,r,end);
  const [x2,y2] = polar(cx,cy,r,start);
  const large = Math.abs(end-start) <= 180 ? 0 : 1;
  return `<path d="M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${r} ${r} 0 ${large} 0 ${x2.toFixed(2)} ${y2.toFixed(2)}" fill="none" ${attrs}/>`;
};

const node = (x,y,label,small=false) => `<circle cx="${x}" cy="${y}" r="${small ? 24 : 34}" fill="#fff" stroke="${ink}" stroke-width="2"/><text x="${x}" y="${y+7}" text-anchor="middle" font-family="Georgia, serif" font-size="${small ? 20 : 24}" fill="${ink}">${label}</text>`;

function marketPanel(cx, scenario, wic = false) {
  const cy = 420;
  const r = 155;
  const online = scenario > 1;
  const wicOnline = wic && scenario === 3;
  let body = `<text x="${cx}" y="180" text-anchor="middle" font-family="Arial, sans-serif" font-size="25" font-weight="600" fill="${ink}">${wic ? 'WIC Segment' : 'Non-WIC Segment'}</text>`;
  if (online && (!wic || wicOnline)) {
    body += `<path d="M ${cx} ${cy} L ${cx+110} ${cy-110} A ${r} ${r} 0 0 1 ${cx+110} ${cy+110} Z" fill="#eef3f1"/>
      <path d="M ${cx} ${cy} L ${cx-110} ${cy+110} A ${r} ${r} 0 0 1 ${cx-110} ${cy-110} Z" fill="#eef3f1"/>`;
  }
  body += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${ink}" stroke-width="2.2"/>`;
  if (wic) {
    body += `<line x1="${cx-r}" y1="${cy}" x2="${cx+r}" y2="${cy}" stroke="${muted}" stroke-width="1.5"/>`;
    if (wicOnline) {
      body += `<line x1="${cx}" y1="${cy}" x2="${cx+112}" y2="${cy-108}" stroke="${muted}"/><line x1="${cx}" y1="${cy}" x2="${cx-112}" y2="${cy-108}" stroke="${muted}"/>
        ${node(cx,cy,'E',true)}`;
    } else body += `<circle cx="${cx}" cy="${cy}" r="4" fill="${ink}"/>`;
    body += node(cx,cy-r,'W₁') + node(cx,cy+r,'W₂');
    body += arc(cx,cy,r+43,-87,-5,`stroke="${accent}" stroke-width="2"`) + arc(cx,cy,r+43,5,87,`stroke="${accent}" stroke-width="2"`);
    body += `<text x="${cx+145}" y="${cy-115}" font-family="Georgia, serif" font-size="22" fill="${accent}">z${scenario}</text>`;
  } else {
    const span = scenario === 1 ? 36 : scenario === 2 ? 43 : 47;
    for (const base of [0,90,180,270]) {
      for (const side of [-1,1]) {
        const [x,y] = polar(cx,cy,r,base+side*span);
        body += `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="${muted}" stroke-width="1.2"/>`;
      }
    }
    body += node(cx,cy-r,'W₁') + node(cx+r,cy,'NW₁') + node(cx,cy+r,'W₂') + node(cx-r,cy,'NW₂');
    if (online) body += node(cx,cy,'E',true);
    else body += `<circle cx="${cx}" cy="${cy}" r="4" fill="${ink}"/>`;
    body += `<text x="${cx+72}" y="${cy-170}" font-family="Georgia, serif" font-size="21" fill="${accent}">x${scenario}</text>
      <text x="${cx+170}" y="${cy-58}" font-family="Georgia, serif" font-size="21" fill="${accent}">y${scenario}</text>`;
    if (online) body += `<text x="${cx+108}" y="${cy+116}" font-family="Georgia, serif" font-size="21" fill="${accent}">E</text>`;
  }
  return body;
}

for (const scenario of [1,2,3]) {
  const title = `Spatial Setting of the Circular Market under Scenario ${scenario} (N = 2)`;
  const body = `${marketPanel(340,scenario,false)}${marketPanel(860,scenario,true)}
    <text x="600" y="790" text-anchor="middle" font-family="Arial, sans-serif" font-size="18" fill="${muted}">W: WIC-authorized retailer · NW: non-authorized retailer${scenario > 1 ? ' · E: e-commerce retailer' : ''}</text>`;
  await writeFile(out(`jmp-scenario-${scenario}.svg`), svgShell(title,body), 'utf8');
}

const source = 'D:\\11. Work\\WIC and Retail Market\\JR Resubmitted\\Retail_Competition_under_the_WIC_Retail_Delivery_System___RIO__latest_version_\\theta_0.4';
const charts = [];
for (const [file,title] of [['CSNW.svg','Non-WIC Consumer Welfare'],['CSW.svg','WIC Consumer Welfare'],['GS.svg','Direct WIC Spending']]) {
  const data = (await readFile(path.join(source,file))).toString('base64');
  charts.push({data,title});
}
const welfareBody = charts.map((chart,index) => {
  const x = 80 + index*370;
  return `<text x="${x+150}" y="158" text-anchor="middle" font-family="Arial, sans-serif" font-size="21" font-weight="600" fill="${ink}">${esc(chart.title)}</text>
    <image x="${x}" y="180" width="300" height="500" preserveAspectRatio="xMidYMid meet" href="data:image/svg+xml;base64,${chart.data}"/>`;
}).join('') + `<text x="600" y="744" text-anchor="middle" font-family="Arial, sans-serif" font-size="17" fill="${muted}">θ = 0.4 · V = 5 · c = 2 · N = 1 · t = 1</text>
<text x="600" y="782" text-anchor="middle" font-family="Arial, sans-serif" font-size="15" fill="${muted}">Feasible μ ranges differ across scenarios because of free-entry equilibrium conditions.</text>`;
await writeFile(out('jmp-welfare-spending.svg'), svgShell('Consumer Welfare and Direct WIC Spending Across Scenarios',welfareBody), 'utf8');

console.log('Generated four JMP carousel SVGs in assets/.');
