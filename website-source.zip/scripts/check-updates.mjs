// Exercise ordinary maintenance in an isolated temporary copy, never the real CV or papers.
import {mkdtemp,mkdir,cp,readFile,writeFile,unlink,stat,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {root} from './build.mjs';

const tempRoot=path.resolve(tmpdir());
const workspace=await mkdtemp(path.join(tempRoot,'ming-ge-maintenance-'));
const run=()=>spawnSync(process.execPath,['scripts/build.mjs'],{cwd:workspace,encoding:'utf8'});
const must=(condition,message)=>{if(!condition)throw new Error(message);};
const hash=buffer=>createHash('sha256').update(buffer).digest('hex');
try{
  for(const directory of ['content','assets','files'])await cp(path.join(root,directory),path.join(workspace,directory),{recursive:true});
  await mkdir(path.join(workspace,'scripts'));
  await cp(path.join(root,'scripts/build.mjs'),path.join(workspace,'scripts/build.mjs'));
  const contentPath=path.join(workspace,'content/site.json');
  const data=JSON.parse(await readFile(contentPath,'utf8'));
  data.profile.intro='A changed introduction & <safe text>.';
  data.research.workingPapers.push({id:'maintenance-check',title:'Maintenance check',authors:['Ming Ge'],links:[{label:'Read paper',url:'files/maintenance-check.pdf',type:'pdf'}]});
  await cp(path.join(workspace,'files/cv.pdf'),path.join(workspace,'files/maintenance-check.pdf'));
  await cp(path.join(workspace,'files/cv.pdf'),path.join(workspace,'files/job-market-paper.pdf'));
  await writeFile(contentPath,JSON.stringify(data,null,2));
  let result=run();must(result.status===0,result.stderr);
  const home=await readFile(path.join(workspace,'dist/index.html'),'utf8');
  must(home.includes('A changed introduction &amp; &lt;safe text&gt;.'),'Profile edits were not safely rendered.');
  must((await readFile(path.join(workspace,'dist/research/index.html'),'utf8')).includes('id="maintenance-check"'),'New paper not rendered.');
  must(hash(await readFile(path.join(workspace,'files/cv.pdf')))===hash(await readFile(path.join(workspace,'dist/files/job-market-paper.pdf'))),'Replacing a fixed PDF filename did not update the published copy.');
  data.research.workingPapers=data.research.workingPapers.filter(paper=>paper.id!=='maintenance-check');
  await unlink(path.join(workspace,'files/maintenance-check.pdf'));
  await writeFile(contentPath,JSON.stringify(data,null,2));
  result=run();must(result.status===0,result.stderr);
  must(!(await stat(path.join(workspace,'dist/files/maintenance-check.pdf')).catch(()=>null)),'Removed source PDF still exists in generated files.');
  const before=await readFile(path.join(workspace,'dist/index.html'),'utf8');
  data.profile.cv='files/does-not-exist.pdf';
  await writeFile(contentPath,JSON.stringify(data,null,2));
  result=run();must(result.status!==0&&result.stderr.includes('Missing file'),'Missing files should produce a clear build error.');
  must(before===await readFile(path.join(workspace,'dist/index.html'),'utf8'),'Invalid updates changed the previously generated page.');
  console.log('Passed: edit biography, add paper, replace PDF, remove obsolete PDF, and reject missing files without changing prior output.');
}finally{
  const resolved=path.resolve(workspace);
  if(path.dirname(resolved)!==tempRoot||!path.basename(resolved).startsWith('ming-ge-maintenance-'))throw new Error('Temporary cleanup path failed validation.');
  await rm(resolved,{recursive:true,force:true});
}
