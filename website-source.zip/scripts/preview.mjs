import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { build } from './build.mjs';

const {output} = await build();
const port = Number(process.env.PORT || 4173);
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.pdf':'application/pdf','.xml':'application/xml; charset=utf-8','.txt':'text/plain; charset=utf-8'};
// Build again on page navigation, so replacing a PDF or editing content is reflected on refresh.
let rebuilding;
const rebuild = async () => {
  if (!rebuilding) rebuilding = build({quiet:true}).finally(()=>{rebuilding=undefined;});
  await rebuilding;
};
const server = http.createServer(async(req,res)=>{
  try {
    if (!['GET','HEAD'].includes(req.method)) {res.writeHead(405,{'Allow':'GET, HEAD'});res.end();return;}
    const pathname = decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    const rootPath = path.resolve(output);
    let file = path.resolve(rootPath,`.${pathname}`);
    if (file !== rootPath && !file.startsWith(rootPath+path.sep)) {res.writeHead(403);res.end('Forbidden');return;}
    if (pathname.endsWith('/') || pathname.endsWith('.html')) await rebuild();
    const info = await stat(file).catch(()=>null);
    if (info?.isDirectory()) {
      if (!pathname.endsWith('/')) {res.writeHead(301,{'Location':pathname+'/'});res.end();return;}
      file=path.join(file,'index.html');
    }
    let body; let status=200;
    try {body=await readFile(file);} catch {body=await readFile(path.join(output,'404.html'));file='404.html';status=404;}
    res.writeHead(status,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    res.end(req.method==='HEAD'?undefined:body);
  } catch(error) {
    res.writeHead(500,{'Content-Type':'text/plain; charset=utf-8'});
    res.end(`Preview could not rebuild. Your source files are unchanged.\n\n${error.message}`);
  }
});
server.on('error',error=>{console.error(error.code==='EADDRINUSE'?`Port ${port} is already in use. Open the existing preview, or set PORT to a different number.`:error.message);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>console.log(`Local: http://127.0.0.1:${port}/\nEdit content/site.json or replace files, then refresh the browser.\nPress Ctrl+C to stop. This preview is only accessible on this computer.`));
