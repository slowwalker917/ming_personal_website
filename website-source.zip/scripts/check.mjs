import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
import {build} from './build.mjs';

const {output,data}=await build({quiet:true});
const pages=['index.html','research/index.html','teaching/index.html','404.html'];
const problems=[];
let checked=0;
for(const file of pages){
  const html=await readFile(path.join(output,file),'utf8');
  if((html.match(/<h1(?:\s|>)/g)||[]).length!==1)problems.push(`${file}: expected one h1`);
  const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]);
  if(new Set(ids).size!==ids.length)problems.push(`${file}: duplicate id`);
  if(!html.includes('name="viewport"'))problems.push(`${file}: missing viewport`);
  for(const match of html.matchAll(/(?:href|src)="([^"]+)"/g)){
    let url=match[1].replaceAll('&amp;','&');
    if(/^(https?:|mailto:|tel:)/.test(url))continue;
    const [urlPath,hash]=url.split('#');
    let target=urlPath.startsWith('/')?path.join(output,urlPath):path.resolve(path.dirname(path.join(output,file)),urlPath||path.basename(file));
    const info=await stat(target).catch(()=>null);
    if(info?.isDirectory())target=path.join(target,'index.html');
    if(!(await stat(target).catch(()=>null))?.isFile()){problems.push(`${file}: missing ${url}`);continue;}
    checked++;
    if(hash){const body=await readFile(target,'utf8');if(!body.includes(`id="${hash}"`))problems.push(`${file}: missing anchor ${url}`);}
  }
}
for(const filename of ['cv.pdf','job-market-paper.pdf','statistics-syllabus.pdf','reputation-search-paper.pdf']){
  const buffer=await readFile(path.join(output,'files',filename));
  if(!buffer.subarray(0,5).equals(Buffer.from('%PDF-')))problems.push(`Invalid PDF: ${filename}`);
}
const researchHtml=await readFile(path.join(output,'research/index.html'),'utf8');
for(const paper of [data.research.jobMarketPaper,...data.research.publications,...data.research.workingPapers,...data.research.workInProgress]){
  if(!researchHtml.includes(`id="${paper.id}"`))problems.push(`Missing research item: ${paper.id}`);
}
if(problems.length){console.error(problems.join('\n'));process.exitCode=1;}else{console.log(`Passed: ${pages.length} HTML pages, ${checked} local links and assets, all 9 research items, 4 PDF headers.`);}
